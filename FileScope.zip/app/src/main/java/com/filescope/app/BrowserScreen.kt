package com.filescope.app

import android.os.Environment
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private sealed interface Dlg {
    data object NewFolder : Dlg
    data class Rename(val f: File) : Dlg
    data class Delete(val fs: List<File>) : Dlg
    data class Extract(val f: File) : Dlg
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val home = remember { Environment.getExternalStorageDirectory() }

    var dirPath by rememberSaveable { mutableStateOf(home.path) }
    val dir = File(dirPath)
    var showHidden by rememberSaveable { mutableStateOf(true) }
    var sort by remember { mutableStateOf(FileOps.Sort.NAME) }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var entries by remember { mutableStateOf<List<File>>(emptyList()) }
    var found by remember { mutableStateOf<List<File>>(emptyList()) }
    var tick by remember { mutableIntStateOf(0) }
    val selected = remember { mutableStateListOf<File>() }
    var clip by remember { mutableStateOf<List<File>>(emptyList()) }
    var cut by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var busy by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }

    LaunchedEffect(dirPath, showHidden, sort, tick) {
        entries = withContext(Dispatchers.IO) { FileOps.list(File(dirPath), showHidden, sort) }
    }
    LaunchedEffect(query, dirPath, showHidden) {
        if (query.length >= 2) {
            delay(300)
            found = withContext(Dispatchers.IO) { FileOps.search(File(dirPath), query, showHidden) }
        } else found = emptyList()
    }

    val shown = when {
        query.isBlank() -> entries
        query.length < 2 -> entries.filter { it.name.contains(query, ignoreCase = true) }
        else -> found
    }

    fun go(d: File) {
        selected.clear(); query = ""; searching = false
        dirPath = d.path
    }

    fun work(block: () -> Unit) {
        scope.launch {
            busy = true
            val err = withContext(Dispatchers.IO) {
                try { block(); null } catch (e: Exception) { e.message ?: "خطا" }
            }
            busy = false
            if (err != null) toast(ctx, err)
            selected.clear()
            tick++
        }
    }

    fun toggle(f: File) {
        if (f in selected) selected.remove(f) else selected.add(f)
    }

    BackHandler(enabled = selected.isNotEmpty() || searching || dirPath != home.path) {
        when {
            selected.isNotEmpty() -> selected.clear()
            searching -> { searching = false; query = "" }
            else -> dir.parentFile?.let { go(it) }
        }
    }

    Scaffold(
        topBar = {
            if (selected.isNotEmpty()) {
                TopAppBar(
                    title = { Text("${selected.size} مورد") },
                    navigationIcon = {
                        IconButton(onClick = { selected.clear() }) { Icon(Icons.Filled.Close, "بستن") }
                    },
                    actions = {
                        IconButton(onClick = { val all = shown.toList(); selected.clear(); selected.addAll(all) }) {
                            Icon(Icons.Filled.SelectAll, "انتخاب همه")
                        }
                        IconButton(onClick = { clip = selected.toList(); cut = false; selected.clear() }) {
                            Icon(Icons.Filled.ContentCopy, "کپی")
                        }
                        IconButton(onClick = { clip = selected.toList(); cut = true; selected.clear() }) {
                            Icon(Icons.Filled.ContentCut, "برش")
                        }
                        IconButton(onClick = { dlg = Dlg.Delete(selected.toList()) }) {
                            Icon(Icons.Filled.Delete, "حذف")
                        }
                        Box {
                            IconButton(onClick = { moreMenu = true }) { Icon(Icons.Filled.MoreVert, "بیشتر") }
                            DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                                if (selected.size == 1) {
                                    DropdownMenuItem(
                                        text = { Text("تغییر نام") },
                                        onClick = { moreMenu = false; dlg = Dlg.Rename(selected.first()) }
                                    )
                                }
                                DropdownMenuItem(
                                    text = { Text("فشرده‌سازی (ZIP)") },
                                    onClick = {
                                        moreMenu = false
                                        val fs = selected.toList()
                                        val d = dir
                                        val base = if (fs.size == 1) fs[0].nameWithoutExtension else "archive"
                                        work { FileOps.zip(fs, FileOps.unique(d, "$base.zip")) }
                                    }
                                )
                                if (selected.size == 1 && selected.first().extension.equals("zip", true)) {
                                    DropdownMenuItem(
                                        text = { Text("استخراج ZIP") },
                                        onClick = { moreMenu = false; dlg = Dlg.Extract(selected.first()) }
                                    )
                                }
                            }
                        }
                    }
                )
            } else {
                TopAppBar(
                    title = {
                        if (searching) {
                            TextField(
                                value = query,
                                onValueChange = { query = it },
                                singleLine = true,
                                placeholder = { Text("جستجو در این پوشه…") },
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent
                                )
                            )
                        } else {
                            Column {
                                Text(
                                    if (dirPath == home.path) "حافظه داخلی" else dir.name,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    dir.path,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        if (dirPath != home.path) {
                            IconButton(onClick = { dir.parentFile?.let { go(it) } }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, "بالا")
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = { searching = !searching; if (!searching) query = "" }) {
                            Icon(Icons.Filled.Search, "جستجو")
                        }
                        IconButton(onClick = { showHidden = !showHidden }) {
                            Icon(
                                if (showHidden) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                "فایل‌های مخفی"
                            )
                        }
                        Box {
                            IconButton(onClick = { sortMenu = true }) { Icon(Icons.Filled.Sort, "مرتب‌سازی") }
                            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                                listOf(
                                    FileOps.Sort.NAME to "نام",
                                    FileOps.Sort.SIZE to "حجم",
                                    FileOps.Sort.DATE to "تاریخ"
                                ).forEach { (s, t) ->
                                    DropdownMenuItem(
                                        text = { Text((if (sort == s) "✓ " else "") + t) },
                                        onClick = { sort = s; sortMenu = false }
                                    )
                                }
                            }
                        }
                        IconButton(onClick = { dlg = Dlg.NewFolder }) {
                            Icon(Icons.Filled.CreateNewFolder, "پوشه جدید")
                        }
                        if (clip.isNotEmpty()) {
                            IconButton(onClick = {
                                val c = clip; val mv = cut; val d = dir
                                clip = emptyList()
                                work { c.forEach { if (mv) FileOps.move(it, d) else FileOps.copy(it, d) } }
                            }) { Icon(Icons.Filled.ContentPaste, "چسباندن") }
                        }
                    }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (shown.isEmpty()) {
                Text(
                    "اینجا چیزی نیست (یا اندروید اجازه‌ی دیدن این پوشه را نمی‌دهد)",
                    modifier = Modifier.align(Alignment.Center).padding(24.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(shown, key = { it.path }) { f ->
                    FileRow(
                        f = f,
                        selected = f in selected,
                        onClick = {
                            when {
                                selected.isNotEmpty() -> toggle(f)
                                f.isDirectory -> go(f)
                                f.extension.equals("zip", true) -> dlg = Dlg.Extract(f)
                                else -> openFile(ctx, f)
                            }
                        },
                        onLong = { toggle(f) }
                    )
                }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
        }
    }

    when (val d = dlg) {
        null -> {}
        Dlg.NewFolder -> TextDialog("پوشه جدید", "", "ایجاد", { dlg = null }) { name ->
            dlg = null
            val parent = dir
            work { if (!File(parent, name).mkdirs()) throw Exception("ساخت پوشه ممکن نشد") }
        }
        is Dlg.Rename -> TextDialog("تغییر نام", d.f.name, "تأیید", { dlg = null }) { name ->
            dlg = null
            work { if (!d.f.renameTo(File(d.f.parentFile, name))) throw Exception("تغییر نام ممکن نشد") }
        }
        is Dlg.Delete -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text("حذف") },
            text = { Text("${d.fs.size} مورد برای همیشه حذف شود؟") },
            confirmButton = {
                TextButton(onClick = {
                    dlg = null
                    work { d.fs.forEach { it.deleteRecursively() } }
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("لغو") } }
        )
        is Dlg.Extract -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text("استخراج ZIP") },
            text = { Text("در پوشه‌ی «${d.f.nameWithoutExtension}» کنار فایل استخراج شود؟") },
            confirmButton = {
                TextButton(onClick = {
                    dlg = null
                    work { FileOps.unzip(d.f, File(d.f.parentFile, d.f.nameWithoutExtension)) }
                }) { Text("استخراج") }
            },
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("لغو") } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileRow(f: File, selected: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg = if (selected) cs.primaryContainer else Color.Transparent
    val isDir = f.isDirectory
    Row(
        Modifier
            .fillMaxWidth()
            .background(bg)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val kind = if (isDir) null else kindByExt(f)
        when {
            isDir -> Icon(Icons.Filled.Folder, null, Modifier.size(44.dp), tint = cs.primary)
            kind != null -> Thumb(f, kind, Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)))
            else -> Icon(Icons.Filled.Description, null, Modifier.size(44.dp), tint = cs.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                f.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (f.name.startsWith(".")) cs.onSurface.copy(alpha = 0.6f) else cs.onSurface
            )
            val sub = if (isDir) fmtDate(f.lastModified())
            else humanSize(f.length()) + "  ·  " + fmtDate(f.lastModified())
            Text(sub, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
        }
        if (selected) Icon(Icons.Filled.CheckCircle, null, tint = cs.primary)
    }
}
