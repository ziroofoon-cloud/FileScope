package com.filescope.app

import android.os.Environment
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun HiddenMediaScreen() {
    var onlyHidden by remember { mutableStateOf(true) }
    var filter by remember { mutableStateOf<MediaKind?>(null) }
    var list by remember { mutableStateOf<List<GridItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<GridItem?>(null) }

    LaunchedEffect(onlyHidden, tick) {
        loading = true
        list = withContext(Dispatchers.IO) {
            MediaScanner.scan(Environment.getExternalStorageDirectory(), onlyHidden)
        }
        loading = false
    }
    val shown = list.filter { filter == null || it.kind == filter }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("رسانه‌های مخفی", style = MaterialTheme.typography.titleLarge)
                Text(
                    if (loading) "در حال اسکن حافظه…" else "${shown.size} مورد",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = { tick++ }) { Icon(Icons.Filled.Refresh, "اسکن دوباره") }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(selected = filter == null, onClick = { filter = null }, label = { Text("همه") })
            FilterChip(
                selected = filter == MediaKind.IMAGE,
                onClick = { filter = MediaKind.IMAGE }, label = { Text("عکس") }
            )
            FilterChip(
                selected = filter == MediaKind.VIDEO,
                onClick = { filter = MediaKind.VIDEO }, label = { Text("ویدیو") }
            )
            Spacer(Modifier.weight(1f))
            Text("فقط مخفی‌ها", style = MaterialTheme.typography.labelMedium)
            Switch(checked = onlyHidden, onCheckedChange = { onlyHidden = it })
        }
        Spacer(Modifier.height(6.dp))
        if (loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("چیزی پیدا نشد", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            MediaGrid(shown) { open = it }
        }
    }
    open?.let { MediaDialog(it, onDismiss = { open = null }, onChanged = { tick++ }) }
}

@Composable
fun CacheScreen() {
    val ctx = LocalContext.current
    var useRoot by remember { mutableStateOf(false) }
    var list by remember { mutableStateOf<List<GridItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<GridItem?>(null) }

    LaunchedEffect(useRoot, tick) {
        loading = true
        val rootOk = if (useRoot) withContext(Dispatchers.IO) { RootShell.available() } else true
        if (!rootOk) {
            toast(ctx, "دسترسی روت در دسترس نیست")
            useRoot = false
        }
        list = withContext(Dispatchers.IO) { CacheScanner.scan(ctx, useRoot && rootOk) }
        loading = false
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("کش برنامه‌ها", style = MaterialTheme.typography.titleLarge)
                Text(
                    if (loading) "در حال اسکن…" else "${list.size} ویدیو/عکس پیدا شد",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = { tick++ }) { Icon(Icons.Filled.Refresh, "اسکن دوباره") }
        }
        Card(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    "ویدیوهایی که در اینستاگرام، X و ... تماشا کرده‌اید گاهی در کش برنامه می‌مانند. " +
                        "اینجا فقط فایل‌هایی نشان داده می‌شوند که واقعاً قابل‌پخش‌اند. کش بعد از مدتی پاک می‌شود، پس زود سراغش بیایید.",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    "اگر لیست خالی است: اندروید ۱۱+ دسترسی مستقیم به Android/data را بسته است؛ با روت می‌شود، " +
                        "یا Shizuku (در نسخه بعد).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("استفاده از روت", Modifier.weight(1f))
                    Switch(checked = useRoot, onCheckedChange = { useRoot = it })
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        if (loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("چیزی پیدا نشد", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            MediaGrid(list) { open = it }
        }
    }
    open?.let { MediaDialog(it, onDismiss = { open = null }, onChanged = { tick++ }) }
}

@Composable
fun AppsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var sel by remember { mutableStateOf<AppInfo?>(null) }

    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { AppUtil.load(ctx) } }
    val shown = apps.filter {
        query.isBlank() || it.label.contains(query, true) || it.pkg.contains(query, true)
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            placeholder = { Text("جستجوی برنامه…") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            modifier = Modifier.fillMaxWidth().padding(14.dp)
        )
        LazyColumn(Modifier.fillMaxSize()) {
            items(shown, key = { it.pkg }) { a ->
                ListItem(
                    headlineContent = { Text(a.label) },
                    supportingContent = { Text(a.pkg, style = MaterialTheme.typography.labelSmall) },
                    leadingContent = { AppIcon(a, 44) },
                    modifier = Modifier.clickable { sel = a }
                )
            }
        }
    }

    sel?.let { a ->
        AlertDialog(
            onDismissRequest = { sel = null },
            title = { Text(a.label) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppIcon(a, 96)
                    Text(a.pkg, style = MaterialTheme.typography.bodySmall)
                    FilledTonalButton(
                        onClick = {
                            scope.launch {
                                val r = withContext(Dispatchers.IO) { runCatching { AppUtil.saveIcon(ctx, a) } }
                                r.onSuccess { toast(ctx, "آیکون ذخیره شد: Pictures/FileScope/Icons") }
                                r.onFailure { toast(ctx, "ذخیره نشد: " + it.message) }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("ذخیره‌ی لوگو (PNG)") }
                    FilledTonalButton(
                        onClick = {
                            scope.launch {
                                val r = withContext(Dispatchers.IO) { runCatching { AppUtil.saveApk(a) } }
                                r.onSuccess { toast(ctx, "APK ذخیره شد: Download/FileScope") }
                                r.onFailure { toast(ctx, "ذخیره نشد: " + it.message) }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("ذخیره‌ی فایل APK") }
                }
            },
            confirmButton = { TextButton(onClick = { sel = null }) { Text("بستن") } }
        )
    }
}

@Composable
private fun AppIcon(a: AppInfo, sizeDp: Int) {
    val ctx = LocalContext.current
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, a.pkg) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                ctx.packageManager.getApplicationIcon(a.pkg).toBitmap(sizeDp * 3, sizeDp * 3).asImageBitmap()
            }.getOrNull()
        }
    }
    val b = bmp
    if (b != null) Image(b, null, Modifier.size(sizeDp.dp)) else Spacer(Modifier.size(sizeDp.dp))
}
