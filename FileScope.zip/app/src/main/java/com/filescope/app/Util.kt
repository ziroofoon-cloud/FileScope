package com.filescope.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.os.Environment
import android.util.LruCache
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class MediaKind { VIDEO, IMAGE, AUDIO }

data class Sniffed(val kind: MediaKind, val ext: String)

/** یک آیتم رسانه‌ای برای نمایش در شبکه (گرید) */
data class GridItem(val file: File, val kind: MediaKind, val ext: String, val label: String)

data class AppInfo(val label: String, val pkg: String, val apk: String)

val IMG_EXT = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic")
val VID_EXT = setOf("mp4", "mkv", "webm", "3gp", "mov", "avi")

fun kindByExt(f: File): MediaKind? {
    val e = f.extension.lowercase()
    return when {
        e in IMG_EXT -> MediaKind.IMAGE
        e in VID_EXT -> MediaKind.VIDEO
        else -> null
    }
}

fun mimeFor(ext: String): String =
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase()) ?: "*/*"

fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()

fun humanSize(b: Long): String {
    if (b < 1024) return "$b B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = -1
    while (v >= 1024 && i < units.lastIndex) {
        v /= 1024
        i++
    }
    return String.format(Locale.US, "%.1f %s", v, units[i])
}

fun fmtDate(ms: Long): String =
    SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.getDefault()).format(Date(ms))

fun openFile(ctx: Context, f: File, mime: String? = null) {
    try {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".provider", f)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime ?: mimeFor(f.extension))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, null))
    } catch (e: Exception) {
        toast(ctx, "برنامه‌ای برای باز کردن این فایل پیدا نشد")
    }
}

/** تشخیص نوع واقعی فایل از روی بایت‌های ابتدایی (حتی بدون پسوند یا با پسوند .exo/.tmp) */
object Sniff {
    fun of(f: File): Sniffed? {
        val b = ByteArray(16)
        val n = try {
            f.inputStream().use { it.read(b) }
        } catch (e: Exception) {
            return null
        }
        if (n < 12) return null
        return when {
            m(b, 4, 0x66, 0x74, 0x79, 0x70) -> {
                val brand = String(b, 8, 4, Charsets.ISO_8859_1)
                when {
                    brand == "M4A " || brand == "M4B " -> Sniffed(MediaKind.AUDIO, "m4a")
                    brand.startsWith("hei") || brand == "mif1" || brand == "avif" ->
                        Sniffed(MediaKind.IMAGE, "heic")
                    brand.startsWith("qt") -> Sniffed(MediaKind.VIDEO, "mov")
                    else -> Sniffed(MediaKind.VIDEO, "mp4")
                }
            }
            m(b, 0, 0x1A, 0x45, 0xDF, 0xA3) -> Sniffed(MediaKind.VIDEO, "webm")
            m(b, 0, 0xFF, 0xD8, 0xFF) -> Sniffed(MediaKind.IMAGE, "jpg")
            m(b, 0, 0x89, 0x50, 0x4E, 0x47) -> Sniffed(MediaKind.IMAGE, "png")
            m(b, 0, 0x52, 0x49, 0x46, 0x46) && m(b, 8, 0x57, 0x45, 0x42, 0x50) ->
                Sniffed(MediaKind.IMAGE, "webp")
            m(b, 0, 0x47, 0x49, 0x46, 0x38) -> Sniffed(MediaKind.IMAGE, "gif")
            m(b, 0, 0x49, 0x44, 0x33) -> Sniffed(MediaKind.AUDIO, "mp3")
            else -> null
        }
    }

    private fun m(b: ByteArray, off: Int, vararg v: Int): Boolean =
        v.indices.all { (b[off + it].toInt() and 0xFF) == v[it] }
}

/** تصویر بندانگشتی عکس و ویدیو */
object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(120) {}

    fun get(file: File, kind: MediaKind, size: Int = 256): Bitmap? {
        val key = file.path + "|" + file.lastModified()
        cache.get(key)?.let { return it }
        val bmp: Bitmap? = try {
            when (kind) {
                MediaKind.IMAGE -> decodeImage(file, size)
                MediaKind.VIDEO -> decodeVideo(file)
                MediaKind.AUDIO -> null
            }
        } catch (e: Throwable) {
            null
        }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }

    private fun decodeImage(file: File, size: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= size && o.outHeight / (s * 2) >= size) s *= 2
        return BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun decodeVideo(file: File): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.path)
            r.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: r.getFrameAtTime(0)
        } finally {
            try { r.release() } catch (e: Exception) {}
        }
    }
}

/** ذخیره در گالری */
object Gallery {
    fun save(ctx: Context, f: File, kind: MediaKind, ext: String): File {
        val type = if (kind == MediaKind.VIDEO) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
        val dir = File(Environment.getExternalStoragePublicDirectory(type), "FileScope").apply { mkdirs() }
        val name = if (f.extension.equals(ext, true) && f.nameWithoutExtension.isNotBlank())
            f.name.trimStart('.')
        else "FileScope_${System.currentTimeMillis()}.$ext"
        val out = FileOps.unique(dir, name)
        f.copyTo(out)
        MediaScannerConnection.scanFile(ctx, arrayOf(out.path), null, null)
        return out
    }
}

/** اجرای دستور با روت (فقط اگر گوشی روت باشد) */
object RootShell {
    fun exec(cmd: String): String? = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Exception) {
        null
    }

    fun available(): Boolean = exec("id")?.contains("uid=0") == true
}

/** لیست برنامه‌ها، آیکون و APK */
object AppUtil {
    fun load(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0)
            .map { AppInfo(pm.getApplicationLabel(it).toString(), it.packageName, it.sourceDir) }
            .sortedBy { it.label.lowercase() }
    }

    fun saveIcon(ctx: Context, a: AppInfo): File {
        val bmp = ctx.packageManager.getApplicationIcon(a.pkg).toBitmap(512, 512)
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            "FileScope/Icons"
        ).apply { mkdirs() }
        val out = FileOps.unique(dir, a.pkg + ".png")
        out.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        MediaScannerConnection.scanFile(ctx, arrayOf(out.path), null, null)
        return out
    }

    fun saveApk(a: AppInfo): File {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "FileScope"
        ).apply { mkdirs() }
        val safe = a.label.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val out = FileOps.unique(dir, "$safe.apk")
        File(a.apk).copyTo(out)
        return out
    }
}
