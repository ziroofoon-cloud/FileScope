package com.filescope.app

import android.graphics.Bitmap
import android.media.MediaScannerConnection
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun Thumb(file: File, kind: MediaKind, modifier: Modifier = Modifier) {
    val bmp by produceState<Bitmap?>(null, file.path) {
        value = withContext(Dispatchers.IO) { Thumbs.get(file, kind) }
    }
    Box(
        modifier.background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Icon(
                if (kind == MediaKind.AUDIO) Icons.Filled.MusicNote else Icons.Filled.Image,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (kind == MediaKind.VIDEO) {
            Icon(
                Icons.Filled.PlayCircle,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
fun TextDialog(
    title: String,
    initial: String,
    ok: String,
    onDismiss: () -> Unit,
    onOk: (String) -> Unit
) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = t, onValueChange = { t = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (t.isNotBlank()) onOk(t.trim()) }) { Text(ok) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("لغو") } }
    )
}

@Composable
fun MediaGrid(list: List<GridItem>, onClick: (GridItem) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(104.dp),
        contentPadding = PaddingValues(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(list, key = { it.file.path }) { g ->
            Box(
                Modifier
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onClick(g) }
            ) {
                Thumb(g.file, g.kind, Modifier.fillMaxSize())
                if (g.label.isNotBlank()) {
                    Text(
                        g.label,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.45f))
                            .padding(horizontal = 4.dp, vertical = 2.dp),
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun MediaDialog(item: GridItem, onDismiss: () -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val noMedia = remember(item.file.path) { File(item.file.parentFile, ".nomedia") }
    var hasNoMedia by remember { mutableStateOf(noMedia.exists()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(item.file.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Thumb(
                    item.file, item.kind,
                    Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(12.dp))
                )
                Text(item.file.path, style = MaterialTheme.typography.bodySmall)
                Text(
                    humanSize(item.file.length()) + "  ·  " + fmtDate(item.file.lastModified()),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FilledTonalButton(
                    onClick = { openFile(ctx, item.file, mimeFor(item.ext)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("باز کردن / پخش") }
                FilledTonalButton(
                    onClick = {
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                runCatching { Gallery.save(ctx, item.file, item.kind, item.ext) }
                            }
                            r.onSuccess { toast(ctx, "در گالری ذخیره شد: " + it.parentFile?.name + "/" + it.name) }
                            r.onFailure { toast(ctx, "ذخیره نشد: " + it.message) }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("ذخیره در گالری") }
                if (hasNoMedia) {
                    FilledTonalButton(
                        onClick = {
                            if (noMedia.delete()) {
                                hasNoMedia = false
                                MediaScannerConnection.scanFile(ctx, arrayOf(item.file.path), null, null)
                                toast(ctx, "فایل .nomedia حذف شد؛ این پوشه به‌زودی در گالری دیده می‌شود")
                            } else toast(ctx, "حذف .nomedia ممکن نشد")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("نمایش کل این پوشه در گالری (حذف .nomedia)") }
                }
                OutlinedButton(
                    onClick = {
                        if (item.file.delete()) {
                            onChanged()
                            onDismiss()
                        } else toast(ctx, "حذف ممکن نشد")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("حذف فایل", color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } }
    )
}
