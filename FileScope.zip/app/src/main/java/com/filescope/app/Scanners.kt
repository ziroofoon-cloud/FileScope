package com.filescope.app

import android.content.Context
import android.os.Environment
import java.io.File

/** پیدا کردن عکس و ویدیوهای مخفی (پوشه‌های دارای .nomedia یا نام‌گذاری‌شده با نقطه) */
object MediaScanner {
    fun scan(root: File, onlyHidden: Boolean): List<GridItem> {
        val out = ArrayList<GridItem>()
        fun walk(dir: File, hiddenCtx: Boolean, depth: Int) {
            if (depth > 14) return
            val children = dir.listFiles() ?: return
            val hid = hiddenCtx || dir.name.startsWith(".") || children.any { it.name == ".nomedia" }
            for (f in children) {
                if (f.isDirectory) {
                    walk(f, hid, depth + 1)
                    continue
                }
                val kind = kindByExt(f) ?: continue
                if (onlyHidden && !(hid || f.name.startsWith("."))) continue
                if (f.length() < 20_000) continue
                out.add(GridItem(f, kind, f.extension.lowercase(), f.parentFile?.name ?: ""))
            }
        }
        walk(root, false, 0)
        return out.sortedByDescending { it.file.lastModified() }
    }
}

/** اسکن کش برنامه‌ها (ویدیو و عکس‌هایی که اینستاگرام، X و ... در حافظه موقت می‌گذارند) */
object CacheScanner {

    fun scan(ctx: Context, useRoot: Boolean): List<GridItem> {
        val out = ArrayList<GridItem>()

        // بدون روت: Android/data/<پکیج>/cache (روی اندروید ۱۰ و پایین‌تر یا با دسترسی مجاز)
        val base = File(Environment.getExternalStorageDirectory(), "Android/data")
        base.listFiles()?.forEach { app ->
            File(app, "cache").walkTopDown().maxDepth(7)
                .filter { it.isFile && it.length() > 150_000 }
                .forEach { f ->
                    val s = Sniff.of(f)
                    if (s != null && s.kind != MediaKind.AUDIO)
                        out.add(GridItem(f, s.kind, s.ext, app.name))
                }
        }

        // با روت: /data/data/<پکیج>/(cache|files)
        if (useRoot) out.addAll(rootScan(ctx))

        return out.sortedByDescending { it.file.lastModified() }
    }

    private fun rootScan(ctx: Context): List<GridItem> {
        val raw = RootShell.exec(
            "find /data/data/*/cache /data/data/*/files -type f -size +150k " +
                "-exec stat -c '%s|%n' {} + 2>/dev/null"
        ) ?: return emptyList()

        val cands = raw.lines().mapNotNull { l ->
            val i = l.indexOf('|')
            if (i <= 0 || !l.substring(i + 1).startsWith("/data/")) return@mapNotNull null
            val size = l.substring(0, i).trim().toLongOrNull() ?: return@mapNotNull null
            size to l.substring(i + 1)
        }.sortedByDescending { it.first }.take(150)
        if (cands.isEmpty()) return emptyList()

        val stage = File(ctx.cacheDir, "rootstage")
        stage.deleteRecursively()
        stage.mkdirs()

        val script = cands.mapIndexed { i, (_, path) ->
            val q = path.replace("'", "'\\''")
            "cp -f '$q' '${stage.path}/r$i' && chmod 666 '${stage.path}/r$i'"
        }.joinToString("\n")
        RootShell.exec(script)

        val out = ArrayList<GridItem>()
        cands.forEachIndexed { i, (_, path) ->
            val f = File(stage, "r$i")
            if (!f.exists()) return@forEachIndexed
            val s = Sniff.of(f)
            if (s == null || s.kind == MediaKind.AUDIO) {
                f.delete()
                return@forEachIndexed
            }
            val named = File(stage, "r$i.${s.ext}")
            val result = if (f.renameTo(named)) named else f
            val pkg = path.split("/").getOrNull(3) ?: "?"
            out.add(GridItem(result, s.kind, s.ext, pkg))
        }
        return out
    }
}
