package com.filescope.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = Color(0xFF4DD6C8),
            onPrimary = Color(0xFF003732),
            primaryContainer = Color(0xFF00504A),
            onPrimaryContainer = Color(0xFFB2F1EA),
            background = Color(0xFF0F1514),
            surface = Color(0xFF0F1514),
            surfaceVariant = Color(0xFF263230),
            onSurfaceVariant = Color(0xFFB7C9C6),
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF00796B),
            onPrimary = Color(0xFFFFFFFF),
            primaryContainer = Color(0xFFB2F1EA),
            onPrimaryContainer = Color(0xFF00201D),
            background = Color(0xFFF7FAF9),
            surface = Color(0xFFF7FAF9),
            surfaceVariant = Color(0xFFDDE8E5),
            onSurfaceVariant = Color(0xFF3F4947),
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
