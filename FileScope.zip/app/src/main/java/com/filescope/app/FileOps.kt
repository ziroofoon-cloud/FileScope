package com.filescope.app

import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object FileOps {
    enum class Sort { NAME, SIZE, DATE }

    fun list(dir: File, showHidden: Boolean, sort: Sort): List<File> {
        val files = dir.listFiles()?.toList() ?: emptyList()
        val filtered = if (showHidden) files else files.filter { !it.name.startsWith(".") }
        val by: Comparator<File> = when (sort) {
            Sort.NAME -> compareBy<File> { it.name.lowercase() }
            Sort.SIZE -> compareByDescending<File> { it.length() }
            Sort.DATE -> compareByDescending<File> { it.lastModified() }
        }
        return filtered.sortedWith(compareByDescending<File> { it.isDirectory }.then(by))
    }

    fun search(root: File, q: String, hidden: Boolean): List<File> =
        root.walkTopDown()
            .onEnter { hidden || !it.name.startsWith(".") }
            .filter { it != root && it.name.contains(q, ignoreCase = true) }
            .take(300)
            .toList()

    fun unique(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (f.exists()) {
            f = File(dir, "$base ($i)$ext")
            i++
        }
        return f
    }

    fun copy(src: File, destDir: File): File {
        if (src.isDirectory && (destDir.canonicalPath + File.separator).startsWith(src.canonicalPath + File.separator))
            throw Exception("نمی‌توان پوشه را داخل خودش کپی کرد")
        val dest = unique(destDir, src.name)
        if (src.isDirectory) src.copyRecursively(dest, overwrite = false) else src.copyTo(dest)
        return dest
    }

    fun move(src: File, destDir: File) {
        if (src.parentFile == destDir) return
        val dest = unique(destDir, src.name)
        if (!src.renameTo(dest)) {
            copy(src, destDir)
            src.deleteRecursively()
        }
    }

    fun zip(files: List<File>, out: File) {
        ZipOutputStream(out.outputStream().buffered()).use { z ->
            for (root in files) {
                val base = root.parentFile ?: continue
                root.walkTopDown().forEach { f ->
                    val rel = f.relativeTo(base).path
                    if (f.isDirectory) {
                        z.putNextEntry(ZipEntry("$rel/"))
                        z.closeEntry()
                    } else {
                        z.putNextEntry(ZipEntry(rel))
                        f.inputStream().use { it.copyTo(z) }
                        z.closeEntry()
                    }
                }
            }
        }
    }

    fun unzip(zip: File, dest: File) {
        dest.mkdirs()
        val root = dest.canonicalPath + File.separator
        ZipInputStream(zip.inputStream().buffered()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val out = File(dest, e.name)
                if (!out.canonicalPath.startsWith(root)) throw SecurityException("مسیر نامعتبر داخل فایل ZIP")
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { z.copyTo(it) }
                }
                z.closeEntry()
                e = z.nextEntry
            }
        }
    }
}
